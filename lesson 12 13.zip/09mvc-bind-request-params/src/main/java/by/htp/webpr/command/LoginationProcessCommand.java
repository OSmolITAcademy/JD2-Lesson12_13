package by.htp.webpr.command;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
@RequestMapping("/loginPage")
public class LoginationProcessCommand {

	@RequestMapping("/about")
	public String goToAboutPage() {
		return "about";
	}

	@RequestMapping("/loginForm")
	public String processFormVersionThree(@RequestParam("login") String theName, Model model) {

		// convert the data to all caps
		theName = theName.toUpperCase();

		// create the message
		String result = "Hey My Friend! " + theName;

		// add message to the model
		model.addAttribute("message", result);

		return "login-page";
	}

}
